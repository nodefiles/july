let user = "vijay";

module.exports.user = user;
