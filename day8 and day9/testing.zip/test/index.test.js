const expect = require("chai").expect;
let app = require("../index");

describe("test for user", function(){
	var index = null;
	this.beforeEach(function(){
        console.log("before each was called")
        index = app;	
    })
	it("should be check for user to be defined", function(){
        expect(index.user).to.be.not.undefined;
    })
	it("should be check for user to be vijay", function(){
        expect(index.user).to.equal("vijay");
    })
	it("should be check for user to be vijay to have 5 chars", function(){
        expect(index.user.length).to.equal(5);
    })
    this.afterEach(function(){
        console.log("after each was called")
        index = null;	
    })
})

