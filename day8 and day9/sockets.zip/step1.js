const express = require("express");
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server);

app.use(express.static(__dirname));
app.use(express.static(__dirname+"/public"));

// let clientlist = 1;
io.on("connection", function(socket){
    console.log("socket connection success");
    socket.emit("serverMessage","Client connected");
   // clientlist++;
    socket.on("disconnect",function(){
        console.log("client disconnected")
    });
});


server.listen(2020);
console.log("server is now live on localhost:2020");
