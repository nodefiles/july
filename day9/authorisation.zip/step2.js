let express = require("express");
let mongoose = require("mongoose");

let app = express();
app.use(express.urlencoded({extended : true}));
//--------------------------------------------------
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User", new Schema({
    id : ObjectId,
    firstname : String,
    lastname : String,
    email : { type : String, unique : true },
    password : String
}));

let dbstring = "mongodb+srv://admin:hzy1eLzFo5Y9kis7@cluster0.20eujo1.mongodb.net/usersDB?retryWrites=true&w=majority";

mongoose.connect(dbstring)
.then(res => console.log("DB Connected"))
.catch(err => console.log("Error", err));

//--------------------------------------------------

app.get("/", (req, res) => {
    res.render("home.pug")
})
app.get("/login", (req, res) => {
    res.render("login.pug")
})
app.post("/login", (req, res) => {
    User.findOne({ email : req.body.email })
    .then( dbres => {
       if(req.body.password === dbres.password ){
        res.redirect("/profile")
       }else{
        res.render("login.pug",{error : "email id or password is wrong"})
       }
    })
    .catch( error => {
        res.render("login.pug", {error : "no users by that credential"} )
    })
})
app.get("/register", (req, res) => {
    res.render("register.pug")
})
app.get("/profile", (req, res) => {
    res.render("profile.pug")
})
app.post("/register", (req, res) => {
    let user = new User({
        firstname : req.body.firstname,
        lastname : req.body.lastname,
        email : req.body.email,
        password : req.body.password
    });

    user.save()
    .then(dbres => res.redirect("/profile"))
    .catch(err => {
        var errormessage = "";
        if(err.code === 11000){
            errormessage = "email id is already registered";
        }else{
            errormessage = "something went wrong please try again";
        }
        res.render("register.pug", { error : errormessage })
    })
})
app.get("/logout", (req, res) => {
    res.redirect("/")
})

app.listen(5050, "localhost", (err) => {
    if(err){
        console.log("Error ", err);
    }else{
        console.log("server is now live on localhost:5050")
    }
});