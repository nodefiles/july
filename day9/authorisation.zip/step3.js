let express = require("express");
let mongoose = require("mongoose");
let session = require("client-sessions");


let app = express();
app.use(express.urlencoded({extended : true}));
app.use(session({
    cookieName : "intellipaat",
    secret : "wertyhnbvdswertyhjhgre345678i9oiutre34567uikmnbvcde4r567u8iolmnbfder4567yu",
    duration : 1000 * 60 * 30,
    activeDuration :  1000 * 60 * 10
}))
//--------------------------------------------------
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User", new Schema({
    id : ObjectId,
    firstname : String,
    lastname : String,
    email : { type : String, unique : true },
    password : String
}));

let dbstring = "mongodb+srv://admin:hzy1eLzFo5Y9kis7@cluster0.20eujo1.mongodb.net/usersDB?retryWrites=true&w=majority";

mongoose.connect(dbstring)
.then(res => console.log("DB Connected"))
.catch(err => console.log("Error", err));

//--------------------------------------------------

app.get("/", (req, res) => {
    res.render("home.pug")
})
app.get("/login", (req, res) => {
    res.render("login.pug")
})
app.post("/login", (req, res) => {
    User.findOne({ email : req.body.email })
    .then( dbres => {
       if(req.body.password === dbres.password ){
        req.intellipaat.user = dbres;
        res.redirect("/profile");
       }else{
        res.render("login.pug",{error : "email id or password is wrong"})
       }
    })
    .catch( error => {
        res.render("login.pug", {error : "no users by that credential"} )
    })
})
app.get("/register", (req, res) => {
    res.render("register.pug")
})
app.get("/profile", (req, res) => {
    // console.log("profile request recieved");
    if(req.intellipaat && req.intellipaat.user){
        User.findOne({ email : req.intellipaat.user.email })
        .then( dbres => {
            res.render("profile.pug",{ info : dbres });
        })
        .catch(error => {
            req.intellipaat.reset();
            res.redirect("/login");
        })
    }else{
        res.redirect("/login");
    }
})
app.post("/register", (req, res) => {
    let user = new User({
        firstname : req.body.firstname,
        lastname : req.body.lastname,
        email : req.body.email,
        password : req.body.password
    });

    user.save()
    .then(dbres => res.redirect("/profile"))
    .catch(err => {
        var errormessage = "";
        if(err.code === 11000){
            errormessage = "email id is already registered";
        }else{
            errormessage = "something went wrong please try again";
        }
        res.render("register.pug", { error : errormessage })
    })
})
app.get("/logout", (req, res) => {
    req.intellipaat.reset();
    res.redirect("/")
})

app.listen(5050, "localhost", (err) => {
    if(err){
        console.log("Error ", err);
    }else{
        console.log("server is now live on localhost:5050")
    }
});